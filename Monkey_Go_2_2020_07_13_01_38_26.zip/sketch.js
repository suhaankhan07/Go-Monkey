var banana, monkey,jungle, stone,ground;
var bananasGroup,obstaclesGroup
var score = 0;



function preload(){
   bananaImg = loadImage("Banana.png")
   stoneImg = loadImage("stone.png")
   groundImg = loadImage("ground.jpg");
   jungleImg = loadImage("jungle.jpg");
  monkeyRunningImg = loadAnimation("Monkey_01.png","Monkey_02.png", "Monkey_03.png","Monkey_04.png", "Monkey_05.png","Monkey_06.png","Monkey_07.png",     "Monkey_08.png","Monkey_09.png","Monkey_10.png");

  }

function setup() {
 createCanvas(400,400);
  
  jungle = createSprite(200,250,400,20);
  jungle.addImage(jungleImg);
  jungle.scale = 0.7;
  
  
 monkey = createSprite(50,340,20,20);
  monkey.addAnimation("running",monkeyRunningImg);
  monkey.scale = 0.1;
  
  ground = createSprite(200,385,400,20);
   ground.visible = false;

  //creates Groups
   bananasGroup = new Group();
   obstaclesGroup = new Group();
  
}


function draw(){
 background(255); 
 edges = createEdgeSprites(); 

   console.log(monkey.y);
  
 monkey.collide(edges);
  monkey.collide(ground);
  
  
  
  if(keyDown("UP_ARROW") && monkey.y > 314) {
    monkey.velocityY = -7;
  }
  
  if(keyDown("RIGHT_ARROW")  ) {
    monkey.velocityX = 5;
  }
  
  if(keyDown("LEFT_ARROW")  ) {
    monkey.velocityX = -5;
  }

  
  monkey.velocityY = monkey.velocityY + 0.2;
  
  //functions
  spawnStones();
  spawnBananas();
  
  
 drawSprites();
  
  //creates score 
   fill(255);
   textSize(20);
   text("score = " + score,250,50);
}

function spawnStones() {
  if(frameCount % 100 === 0) {
     stone = createSprite(200,360,20,20);
     stone.x = random(160,220);
     stone.addImage(stoneImg);
     stone.scale = 0.2; 
     obstaclesGroup.add(stone); 
  }
  
  if(frameCount % 300 === 0) {
     obstaclesGroup.destroyEach(); 
  }
  
  if(monkey.isTouching(obstaclesGroup)) {
    monkey.scale = 0.1;  
  }
}

function spawnBananas() {
  if(frameCount % 100 === 0) {
     banana = createSprite(200,350,20,20);
     banana.x = random(230,360);
     banana.addImage(bananaImg);
     banana.scale = 0.05;
     bananasGroup.add(banana);
  }
  
  if(monkey.isTouching(bananasGroup)) {
     bananasGroup.lifetime = 0;
     bananasGroup.destroyEach(); 
     monkey.scale = monkey.scale + 0.02;
     score = score + 2;
  }
}